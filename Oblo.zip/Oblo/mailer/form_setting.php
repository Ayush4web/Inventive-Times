<?php
	/*Form settings*/
	$subj = "New message from the site 'Oblo - Creative Portfolio Template'"; //letter subject
	$to = 'test@test.com'; // Enter Your E-mail
	$from = 'admin@you-site-name.com'; // Admin e-mail
	$fromName = 'Your Company Name'; // Your company name
	$charset = 'UTF-8';
?>